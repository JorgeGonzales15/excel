package com.isa.platform.u2021.inventory.domain.model.queries;

public record GetProductByIdQuery(Long productId) {

    //pide getear un product por su id y siempre va
}
