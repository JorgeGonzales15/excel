package com.isa.platform.u2021.inventory.domain.model.queries;

public record GetProductBySerialNumberQuery(String serialNumber) {

    //se hizo para obtener el product por serial number del PRODUCT


}
