package com.isa.platform.u2021.monitoring.domain.model.queries;

public record GetSnapshotByIdQuery(Long id) {
    //siempreva
}
