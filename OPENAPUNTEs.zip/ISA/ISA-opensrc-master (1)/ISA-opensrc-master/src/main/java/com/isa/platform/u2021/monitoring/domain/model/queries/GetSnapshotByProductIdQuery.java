package com.isa.platform.u2021.monitoring.domain.model.queries;

public record GetSnapshotByProductIdQuery(Long productId){

    //pide getear snapshot por product id
}
