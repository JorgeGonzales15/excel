package com.kaeser.platform.u2021.inventory.domain.model.queries;

public record GetSparePartByIdQuery(Integer sparePartId) {
}
