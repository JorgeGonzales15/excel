package com.kaeser.platform.u2021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaeserOpensrcApplicationTests {

    @Test
    void contextLoads() {
    }

}
